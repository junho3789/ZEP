
const SPRITE_BUTTON_RUN = App.loadSpritesheet("res/run.png");
const SetRun = (p) => 
{
    if(p.tag.isStun)
        return;

    if(p.tag.isRun) {
        p.tag.isRun = false;
        p.moveSpeed = 90;
    }
    else {
        p.tag.isRun = true;
        p.moveSpeed = 170;
    }

    p.sendUpdated();
}

App.addOnKeyDown(82, function (p) {
    SetRun(p);
});


const Alert = (p, msg, fontSize) => {
    if(p.tag.msgWidget  == null)
    {
        p.tag.msgWidget = p.showWidget("res/msg_widget.html", "top", 400, 120);
        p.tag.msgWidget.sendMessage({
            msg : msg,
            fontSize : fontSize,
            fontWeight : 700,
        });

        App.runLater(() => {
            if(_players.includes(p))
            {
                if(p.tag.msgWidget != null)
                {
                    p.tag.msgWidget.destroy();
                    p.tag.msgWidget = null;
                }
            }
        }, 3);
    }
}

const InitData = (p) =>
{
    p.tag.storage = {
        ver : 2,
        stamp: [false, false, false, false, false],
        questionNum : [0, 0, 0],
    }

    p.sendUpdated();
    SaveData(p);
}

const SaveData = (p) => 
{
    p.storage = JSON.stringify(p.tag.storage);
    p.save();
}

const LoadData = (p) =>
{
    p.tag.storage = JSON.parse(p.storage);
    if(p.tag.storage.ver < 2)
        InitData(p);
    else
        p.sendUpdated();
}

App.onInit.Add(function(){
    App.followPlayer = true;
    App.sendUpdated();
});

App.onStart.Add(function() 
{
    button = App.addMobileButton(8, 135, 45, function (p) 
    {
        SetRun(p);
    });

    button.image = SPRITE_BUTTON_RUN;
    button.sendUpdated();
});

// Stamp widgets are removed while a quiz is open and restored from saved state.
const ShowStampWidget = (p) =>
{
    if(p.tag.quizWidget != null || p.tag.missionWidget != null || p.tag.stampWidget != null)
        return;
    if(p.isMobile)
        p.tag.stampWidget = p.showWidget("res/m_stamp.html", "topleft", 196, 224);
    else
        p.tag.stampWidget = p.showWidget("res/pc_stamp.html", "topleft", 244, 236);
    if(p.tag.stampWidget != null)
        p.tag.stampWidget.sendMessage({stamp : p.tag.storage.stamp});
}

const HideStampWidget = (p) =>
{
    if(p.tag.stampWidget != null)
    {
        p.tag.stampWidget.destroy();
        p.tag.stampWidget = null;
    }
}

// Accept a question number or a course name from map-object metadata.
const QUIZ_COURSE_NUMBERS = {"컴퓨팅사고와sw코딩": 1, "문제해결과알고리즘": 2, "프로그래밍기초와실습": 3, "인공지능기초와활용v2": 4, "데이터분석기초": 5, "인공지능수학기초": 6, "ai알고리즘": 7, "기계학습": 8, "딥러닝": 9, "지능hci": 10, "인공지능시스템": 11, "인공지능수학심화": 12, "ai클라우드컴퓨팅": 13, "강화학습v2": 14, "자연어처리": 15, "음성인식": 16, "영상이해": 17, "비지도학습": 18, "지식표현과추론": 19, "r기초와데이터마트": 20, "ai데이터분석": 21, "첨단심층신경망": 22, "피지컬ai시뮬레이션": 23, "ai모빌리티센서": 24, "강화학습특론": 25, "컴퓨터비전": 26, "뇌인지공학개론": 27, "자율주행": 28, "자료구조와알고리즘1": 29, "인공지능산업": 30, "행정빅데이터분석론": 31, "ai교육데이터의이해와활용": 32, "도시데이터사이언스입문": 33, "ai와스토리텔링": 34, "인공지능시대와ai윤리": 35, "생성형ai기초": 36, "에너지ai": 37, "지능로봇": 38, "iot컴퓨팅": 39};
const ResolveQuizQuestion = (value) =>
{
    const text = String(value == null ? "" : value).trim();
    const key = text.replace(/\s+/g, "").toLowerCase();
    if(Object.prototype.hasOwnProperty.call(QUIZ_COURSE_NUMBERS, key))
        return QUIZ_COURSE_NUMBERS[key];
    const match = key.match(/^(?:quiz)?0*(\d{1,2})(?:번)?$/);
    if(match == null)
        return null;
    const number = Number(match[1]);
    return number >= 1 && number <= 39 ? number : null;
}

const OpenMissionNotice = (p, target) =>
{
    if(p.tag.missionWidget != null || p.tag.quizWidget != null)
        return;
    const widget = p.showWidgetResponsive("res/mission_notice.html", 0, 0, 0, 0);
    if(widget == null)
        return;
    p.tag.missionWidget = widget;
    HideStampWidget(p);
    widget.sendMessage({target : target, stamp : p.tag.storage.stamp});
    widget.onMessage.Add(function(player, msg)
    {
        if(msg.type == "close" && player.tag.missionWidget == widget)
        {
            widget.destroy();
            player.tag.missionWidget = null;
            ShowStampWidget(player);
        }
    });
}

let _players = [];
App.onJoinPlayer.Add(function(p) {
    p.tag = {
        isRun : false,
        storage : null,

        quizWidget : null,
        missionWidget : null,
        msgWidget : null,
        stampWidget : null,

        isEventView : false,
        eventWidget: null,
    }

    if(p.storage == null)
        InitData(p);
    else
        LoadData(p);

    ShowStampWidget(p);

    SetRun(p);
    _players.push(p);
});

App.addOnLocationTouched('Quiz01', function(p) 
{
    if(!p.tag.storage.stamp[0])
        OpenQuiz(p, 1);
});

App.onObjectTouched.Add(function(sender, x, y, object_effect_type, obj) 
{
    if(obj !== null && obj.type == ObjectEffectType.INTERACTION_WITH_ZEPSCRIPTS)
    {
        const rawAction = String(obj.param1 == null ? "" : obj.param1).trim();
        const actions = {quiz01:"Quiz01", quiz02:"Quiz02", quiz03:"Quiz03", eventvideo:"EventVideo", eventsns:"EventSNS"};
        const action = actions[rawAction.toLowerCase()] || (ResolveQuizQuestion(rawAction) != null ? "Quiz02" : rawAction);
        switch(action)
        {
             case "EventVideo":
                switch(obj.text)
                {
                    case "1":
                        EventWidget(sender);
                        break;
                    case "2":
                        if(sender.tag.isEventView)
                            sender.openWebLink("https://www.youtube.com/@aicoss_cnu", false);
                        else
                            Alert(sender, '영상을 시청하고 오세요.', 18);
                        break;
                }
                break;
            case "EventSNS":
                if(sender.tag.isEventView)
                    sender.openWebLink("https://www.instagram.com/jnu_aicoss/?utm_source=ig_web_button_share_sheet&igsh=MXZmdTlzeWJyNTZtOQ#1", false);
                else
                    Alert(sender, '영상을 시청하고 오세요.', 18);
                break;

            case "Quiz01":
                OpenQuiz(sender, 1, 0);
                break;
            case "Quiz02":
                if(sender.tag.storage.stamp[0])
                {
                    let questionNum = ResolveQuizQuestion(obj.text);
                    if(questionNum == null)
                        questionNum = ResolveQuizQuestion(obj.param2);
                    if(questionNum == null && !Object.prototype.hasOwnProperty.call(actions, rawAction.toLowerCase()))
                        questionNum = ResolveQuizQuestion(rawAction);
                    if(questionNum != null)
                        OpenQuiz(sender, 2, questionNum);
                    else
                        OpenMissionNotice(sender, 0);
                }
                else
                    OpenMissionNotice(sender, 2);
                break;
            case "Quiz03":
                let isLastQuestion = true;
                for(let i = 0; i < 4; i++)
                {
                    if(!sender.tag.storage.stamp[i])
                    {
                        isLastQuestion = false;
                        break;
                    }
                }

                if(isLastQuestion)
                    OpenQuiz(sender, 3, obj.text);
                else
                    OpenMissionNotice(sender, 3);
                break;

        }
    }
});

App.onLeavePlayer.Add(function(p)
{
    _players = App.players;
});

const EventWidget = (p) =>
{
    if(p.tag.eventWidget == null)
    {
        if(p.isMobile)
            p.tag.eventWidget = p.showWidget("res/m_eventPopup.html", "middle", 340, 340);    
        else
            p.tag.eventWidget = p.showWidget("res/pc_eventPopup.html", "middle", 640, 640);    

        p.tag.eventWidget.onMessage.Add(function(player, msg)
        {
            if(msg.type == "close")
            {
                player.tag.eventWidget.destroy();
                player.tag.eventWidget = null

                player.tag.isEventView = msg.view;
            }
        });
    }
}

const UpdateStamp = (p, idx, num) =>
{
    switch(idx)
    {
        case 0:
            p.tag.storage.stamp[idx] = true;
            break;
        case 1:
            for(let i = 0; i < 3; i++)
            {
                if(p.tag.storage.questionNum[i] == num)
                    return;
            }

            for(let i = 1; i < 4; i++)
            {
                if(!p.tag.storage.stamp[i])
                {
                    p.tag.storage.questionNum[i - 1] = num;
                    p.tag.storage.stamp[i] = true;
                    break;
                }
            }
            break;
        case 2:
            p.tag.storage.stamp[4] = true;
            break;
    }
    if(p.tag.stampWidget != null)
    {
        p.tag.stampWidget.sendMessage({
            stamp : p.tag.storage.stamp
        });
    }

     SaveData(p);
}

const OpenQuiz = (p, idx, num) =>
{
   if(p.tag.quizWidget == null && p.tag.missionWidget == null)
    {
        p.tag.quizWidget = p.showWidgetResponsive(`res/pc_Quiz${idx}.html`, 0, 0, 0, 0);
        if(p.tag.quizWidget == null && p.tag.missionWidget == null)
            return;
        HideStampWidget(p);

        let isLast = true;
        for(let i = 1; i < 4; i++)
        {
            if(!p.tag.storage.stamp[i])
            {
                isLast = false;
                break;
            }
        }

        if(!isLast)
        {
            isLast = true;
            for(let i = 1; i < 3; i++)
            {
                if(!p.tag.storage.stamp[i] || p.tag.storage.questionNum[i - 1] == num)
                {
                    isLast = false;
                    break;
                }
            }
        }

        p.tag.quizWidget.sendMessage({
            question:num,
            isLastQuestion:isLast
        });

        const quizWidget = p.tag.quizWidget;
        quizWidget.onMessage.Add(function(player, msg)
        {
            if(msg.type == "close" && player.tag.quizWidget == quizWidget)
            {
                quizWidget.destroy();
                player.tag.quizWidget = null

                try
                {
                    if(msg.success)
                        UpdateStamp(player, idx - 1, msg.num);
                }
                finally
                {
                    ShowStampWidget(player);
                }
            }
        });
    } 
}

// Admin/owner command: reset only the command sender's quiz progress.
App.onSay.Add(function(player, text)
{
    if(typeof text != "string" || text.trim() !== "/스탬프초기화")
        return;

    // role is a read-only ZEP permission value: admin 3000, owner 3001.
    if(typeof player.role != "number" || !(player.role >= 3000))
    {
        player.sendMessage("관리자만 사용할 수 있는 명령어입니다.", 0xD35400);
        return;
    }
    if(player.tag == null || player.tag.storage == null)
    {
        player.sendMessage("퀴즈 앱이 준비된 후 다시 입력해 주세요.", 0xD35400);
        return;
    }
    if(player.tag.quizWidget != null || player.tag.missionWidget != null)
    {
        player.sendMessage("퀴즈 또는 안내 창을 닫고 다시 입력해 주세요.", 0xD35400);
        return;
    }

    // Preserve all other saved fields and never modify another player.
    player.tag.storage.stamp = [false, false, false, false, false];
    player.tag.storage.questionNum = [0, 0, 0];
    SaveData(player);
    HideStampWidget(player);
    ShowStampWidget(player);
    player.sendMessage("본인의 스탬프 5개와 풀이 기록을 초기화했습니다.", 0x237A36);
});
