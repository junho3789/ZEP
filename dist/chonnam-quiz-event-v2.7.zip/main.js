
const SPRITE_BUTTON_RUN = App.loadSpritesheet("res/run.png");
const SetRun = (p) => 
{
    if(p.tag.isStun)
        return;

    if(p.tag.isRun) {
        p.tag.isRun = false;
        p.moveSpeed = 90;
    }
    else {
        p.tag.isRun = true;
        p.moveSpeed = 170;
    }

    p.sendUpdated();
}

App.addOnKeyDown(82, function (p) {
    SetRun(p);
});


const Alert = (p, msg, fontSize) => {
    if(p.tag.msgWidget  == null)
    {
        p.tag.msgWidget = p.showWidget("res/msg_widget.html", "top", 400, 120);
        p.tag.msgWidget.sendMessage({
            msg : msg,
            fontSize : fontSize,
            fontWeight : 700,
        });

        App.runLater(() => {
            if(_players.includes(p))
            {
                if(p.tag.msgWidget != null)
                {
                    p.tag.msgWidget.destroy();
                    p.tag.msgWidget = null;
                }
            }
        }, 3);
    }
}

// Space-wide reset metadata is shared by every updated instance of this app.
let _stampResetEpoch = "0";
let _stampSyncWaiting = false;
let _stampSyncCallbacks = [];
let _stampResetBusy = false;
let _stampResetDestroyed = false;
const STAMP_RESET_KEY = "quizStampResetEpoch";

const ReadStampResetStorage = () =>
{
    const raw = App.storage;
    if(raw == null || raw === "")
        return {};
    const data = JSON.parse(raw);
    if(data == null || typeof data != "object" || Array.isArray(data))
        throw new Error("Invalid app storage");
    return data;
}

const StampPlayerIsActive = (player) =>
    !_stampResetDestroyed && _players.includes(player) && player.tag != null && player.tag.storage != null;

const ResetStampProgress = (player, epoch) =>
{
    // Invalidate widget callbacks before destroying an in-progress quiz.
    for(const key of ["quizWidget", "missionWidget"])
    {
        const widget = player.tag[key];
        player.tag[key] = null;
        if(widget != null)
            widget.destroy();
    }
    player.tag.storage.stamp = [false, false, false, false, false];
    player.tag.storage.questionNum = [0, 0, 0];
    player.tag.storage.stampResetEpoch = epoch;
    SaveData(player);
    HideStampWidget(player);
    ShowStampWidget(player);
}

const ApplyStampResetEpoch = (player) =>
{
    if(!StampPlayerIsActive(player))
        return;
    // Missing metadata in older player records means the original generation.
    const saved = String(player.tag.storage.stampResetEpoch == null ? "0" : player.tag.storage.stampResetEpoch);
    if(saved !== _stampResetEpoch)
        ResetStampProgress(player, _stampResetEpoch);
}

const SyncStampResetState = (callback) =>
{
    if(_stampResetDestroyed)
        return;
    if(typeof callback == "function")
        _stampSyncCallbacks.push(callback);
    if(_stampSyncWaiting)
        return;
    _stampSyncWaiting = true;
    const finish = (ok) =>
    {
        if(_stampResetDestroyed)
            return;
        _stampSyncWaiting = false;
        const callbacks = _stampSyncCallbacks;
        _stampSyncCallbacks = [];
        for(const fn of callbacks)
            fn(ok);
    };
    try
    {
        App.getStorage(function()
        {
            if(_stampResetDestroyed)
                return;
            try
            {
                const data = ReadStampResetStorage();
                const epoch = data[STAMP_RESET_KEY];
                if(epoch != null && typeof epoch != "string")
                    throw new Error("Invalid stamp reset epoch");
                _stampResetEpoch = epoch == null ? "0" : epoch;
                for(const player of _players.slice())
                {
                    ApplyStampResetEpoch(player);
                    if(StampPlayerIsActive(player))
                        ShowStampWidget(player);
                }
            }
            catch(error)
            {
                finish(false);
                return;
            }
            finish(true);
        });
    }
    catch(error)
    {
        finish(false);
    }
}

const WithStampResetState = (player, callback) =>
{
    SyncStampResetState(function(ok)
    {
        if(!StampPlayerIsActive(player))
            return;
        if(!ok)
        {
            player.sendMessage("스탬프 기록을 확인하지 못했습니다. 잠시 후 다시 시도해 주세요.", 0xD35400);
            return;
        }
        callback();
    });
}

const IsStampResetAdmin = (player) =>
    typeof player.role == "number" && player.role >= 3000;

const BeginGlobalStampReset = (admin) =>
{
    if(!IsStampResetAdmin(admin) || !StampPlayerIsActive(admin))
        return;
    if(_stampResetBusy)
    {
        admin.sendMessage("전체 초기화를 처리 중입니다. 잠시 기다려 주세요.", 0xD35400);
        return;
    }
    _stampResetBusy = true;
    SyncStampResetState(function(ok)
    {
        if(!StampPlayerIsActive(admin) || !IsStampResetAdmin(admin))
        {
            _stampResetBusy = false;
            return;
        }
        if(!ok)
        {
            _stampResetBusy = false;
            admin.sendMessage("전체 초기화 정보를 읽지 못했습니다. 다시 시도해 주세요.", 0xD35400);
            return;
        }
        try
        {
            const data = ReadStampResetStorage();
            const epoch = Date.now().toString(36) + "-" + Math.random().toString(36).slice(2);
            data[STAMP_RESET_KEY] = epoch;
            const serialized = JSON.stringify(data);
            // Persist before touching any user's progress; retain unrelated app data.
            App.setStorage(serialized);
            App.storage = serialized;
            _stampResetEpoch = epoch;
            for(const player of _players.slice())
                ApplyStampResetEpoch(player);
            admin.sendMessage("전체 스탬프와 풀이 기록을 초기화했습니다. 다른 맵은 동기화 후, 미접속자는 다음 접속 시 적용됩니다.", 0x237A36);
        }
        catch(error)
        {
            admin.sendMessage("전체 초기화를 완료하지 못했습니다. 잠시 후 다시 시도해 주세요.", 0xD35400);
        }
        _stampResetBusy = false;
    });
}

const PollStampResetState = () =>
{
    if(_stampResetDestroyed)
        return;
    SyncStampResetState();
    App.runLater(PollStampResetState, 5);
}

App.onStart.Add(function() { PollStampResetState(); });
App.onDestroy.Add(function()
{
    _stampResetDestroyed = true;
    _stampSyncCallbacks = [];
});

const InitData = (p) =>
{
    p.tag.storage = {
        ver : 2,
        stamp: [false, false, false, false, false],
        questionNum : [0, 0, 0],
        stampResetEpoch : _stampResetEpoch,
    }

    p.sendUpdated();
    SaveData(p);
}

const SaveData = (p) => 
{
    p.storage = JSON.stringify(p.tag.storage);
    p.save();
}

const LoadData = (p) =>
{
    p.tag.storage = JSON.parse(p.storage);
    if(p.tag.storage.ver < 2)
        InitData(p);
    else
        p.sendUpdated();
}

App.onInit.Add(function(){
    App.followPlayer = true;
    App.sendUpdated();
});

App.onStart.Add(function() 
{
    button = App.addMobileButton(8, 135, 45, function (p) 
    {
        SetRun(p);
    });

    button.image = SPRITE_BUTTON_RUN;
    button.sendUpdated();
});

// Stamp widgets are removed while a quiz is open and restored from saved state.
const ShowStampWidget = (p) =>
{
    if(p.tag.quizWidget != null || p.tag.missionWidget != null || p.tag.stampWidget != null)
        return;
    if(p.isMobile)
        p.tag.stampWidget = p.showWidget("res/m_stamp.html", "topleft", 196, 224);
    else
        p.tag.stampWidget = p.showWidget("res/pc_stamp.html", "topleft", 244, 236);
    if(p.tag.stampWidget != null)
        p.tag.stampWidget.sendMessage({stamp : p.tag.storage.stamp});
}

const HideStampWidget = (p) =>
{
    if(p.tag.stampWidget != null)
    {
        p.tag.stampWidget.destroy();
        p.tag.stampWidget = null;
    }
}

// Accept a question number or a course name from map-object metadata.
const QUIZ_COURSE_NUMBERS = {"컴퓨팅사고와sw코딩": 1, "문제해결과알고리즘": 2, "프로그래밍기초와실습": 3, "인공지능기초와활용v2": 4, "데이터분석기초": 5, "인공지능수학기초": 6, "ai알고리즘": 7, "기계학습": 8, "딥러닝": 9, "지능hci": 10, "인공지능시스템": 11, "인공지능수학심화": 12, "ai클라우드컴퓨팅": 13, "강화학습v2": 14, "자연어처리": 15, "음성인식": 16, "영상이해": 17, "비지도학습": 18, "지식표현과추론": 19, "r기초와데이터마트": 20, "ai데이터분석": 21, "첨단심층신경망": 22, "피지컬ai시뮬레이션": 23, "ai모빌리티센서": 24, "강화학습특론": 25, "컴퓨터비전": 26, "뇌인지공학개론": 27, "자율주행": 28, "자료구조와알고리즘1": 29, "인공지능산업": 30, "행정빅데이터분석론": 31, "ai교육데이터의이해와활용": 32, "도시데이터사이언스입문": 33, "ai와스토리텔링": 34, "인공지능시대와ai윤리": 35, "생성형ai기초": 36, "에너지ai": 37, "지능로봇": 38, "iot컴퓨팅": 39};
const ResolveQuizQuestion = (value) =>
{
    const text = String(value == null ? "" : value).trim();
    const key = text.replace(/\s+/g, "").toLowerCase();
    if(Object.prototype.hasOwnProperty.call(QUIZ_COURSE_NUMBERS, key))
        return QUIZ_COURSE_NUMBERS[key];
    const match = key.match(/^(?:quiz)?0*(\d{1,2})(?:번)?$/);
    if(match == null)
        return null;
    const number = Number(match[1]);
    return number >= 1 && number <= 39 ? number : null;
}

const OpenMissionNotice = (p, target) =>
{
    if(p.tag.missionWidget != null || p.tag.quizWidget != null)
        return;
    const widget = p.showWidgetResponsive("res/mission_notice.html", 0, 0, 0, 0);
    if(widget == null)
        return;
    p.tag.missionWidget = widget;
    HideStampWidget(p);
    widget.sendMessage({target : target, stamp : p.tag.storage.stamp});
    widget.onMessage.Add(function(player, msg)
    {
        if(msg.type == "close" && player.tag.missionWidget == widget)
        {
            widget.destroy();
            player.tag.missionWidget = null;
            ShowStampWidget(player);
        }
    });
}

let _players = [];
App.onJoinPlayer.Add(function(p) {
    p.tag = {
        isRun : false,
        storage : null,

        quizWidget : null,
        missionWidget : null,
        msgWidget : null,
        stampWidget : null,

        isEventView : false,
        eventWidget: null,
    }

    if(p.storage == null)
        InitData(p);
    else
        LoadData(p);

    SetRun(p);
    _players.push(p);
    WithStampResetState(p, function() { ShowStampWidget(p); });
});

App.addOnLocationTouched('Quiz01', function(p) 
{
    WithStampResetState(p, function()
    {
        if(!p.tag.storage.stamp[0])
            OpenQuiz(p, 1);
    });
});

App.onObjectTouched.Add(function(sender, x, y, object_effect_type, obj) 
{
    if(obj !== null && obj.type == ObjectEffectType.INTERACTION_WITH_ZEPSCRIPTS)
    {
        WithStampResetState(sender, function()
        {
        const rawAction = String(obj.param1 == null ? "" : obj.param1).trim();
        const actions = {quiz01:"Quiz01", quiz02:"Quiz02", quiz03:"Quiz03", eventvideo:"EventVideo", eventsns:"EventSNS"};
        const action = actions[rawAction.toLowerCase()] || (ResolveQuizQuestion(rawAction) != null ? "Quiz02" : rawAction);
        switch(action)
        {
             case "EventVideo":
                switch(obj.text)
                {
                    case "1":
                        EventWidget(sender);
                        break;
                    case "2":
                        if(sender.tag.isEventView)
                            sender.openWebLink("https://www.youtube.com/@aicoss_cnu", false);
                        else
                            Alert(sender, '영상을 시청하고 오세요.', 18);
                        break;
                }
                break;
            case "EventSNS":
                if(sender.tag.isEventView)
                    sender.openWebLink("https://www.instagram.com/jnu_aicoss/?utm_source=ig_web_button_share_sheet&igsh=MXZmdTlzeWJyNTZtOQ#1", false);
                else
                    Alert(sender, '영상을 시청하고 오세요.', 18);
                break;

            case "Quiz01":
                OpenQuiz(sender, 1, 0);
                break;
            case "Quiz02":
                if(sender.tag.storage.stamp[0])
                {
                    let questionNum = ResolveQuizQuestion(obj.text);
                    if(questionNum == null)
                        questionNum = ResolveQuizQuestion(obj.param2);
                    if(questionNum == null && !Object.prototype.hasOwnProperty.call(actions, rawAction.toLowerCase()))
                        questionNum = ResolveQuizQuestion(rawAction);
                    if(questionNum != null)
                        OpenQuiz(sender, 2, questionNum);
                    else
                        OpenMissionNotice(sender, 0);
                }
                else
                    OpenMissionNotice(sender, 2);
                break;
            case "Quiz03":
                let isLastQuestion = true;
                for(let i = 0; i < 4; i++)
                {
                    if(!sender.tag.storage.stamp[i])
                    {
                        isLastQuestion = false;
                        break;
                    }
                }

                if(isLastQuestion)
                    OpenQuiz(sender, 3, obj.text);
                else
                    OpenMissionNotice(sender, 3);
                break;

        }
        });
    }
});

App.onLeavePlayer.Add(function(p)
{
    _players = App.players;
});

const EventWidget = (p) =>
{
    if(p.tag.eventWidget == null)
    {
        if(p.isMobile)
            p.tag.eventWidget = p.showWidget("res/m_eventPopup.html", "middle", 340, 340);    
        else
            p.tag.eventWidget = p.showWidget("res/pc_eventPopup.html", "middle", 640, 640);    

        p.tag.eventWidget.onMessage.Add(function(player, msg)
        {
            if(msg.type == "close")
            {
                player.tag.eventWidget.destroy();
                player.tag.eventWidget = null

                player.tag.isEventView = msg.view;
            }
        });
    }
}

const UpdateStamp = (p, idx, num) =>
{
    switch(idx)
    {
        case 0:
            p.tag.storage.stamp[idx] = true;
            break;
        case 1:
            for(let i = 0; i < 3; i++)
            {
                if(p.tag.storage.questionNum[i] == num)
                    return;
            }

            for(let i = 1; i < 4; i++)
            {
                if(!p.tag.storage.stamp[i])
                {
                    p.tag.storage.questionNum[i - 1] = num;
                    p.tag.storage.stamp[i] = true;
                    break;
                }
            }
            break;
        case 2:
            p.tag.storage.stamp[4] = true;
            break;
    }
    if(p.tag.stampWidget != null)
    {
        p.tag.stampWidget.sendMessage({
            stamp : p.tag.storage.stamp
        });
    }

     SaveData(p);
}

const OpenQuiz = (p, idx, num) =>
{
   if(p.tag.quizWidget == null && p.tag.missionWidget == null)
    {
        p.tag.quizWidget = p.showWidgetResponsive(`res/pc_Quiz${idx}.html`, 0, 0, 0, 0);
        if(p.tag.quizWidget == null && p.tag.missionWidget == null)
            return;
        HideStampWidget(p);

        let isLast = true;
        for(let i = 1; i < 4; i++)
        {
            if(!p.tag.storage.stamp[i])
            {
                isLast = false;
                break;
            }
        }

        if(!isLast)
        {
            isLast = true;
            for(let i = 1; i < 3; i++)
            {
                if(!p.tag.storage.stamp[i] || p.tag.storage.questionNum[i - 1] == num)
                {
                    isLast = false;
                    break;
                }
            }
        }

        p.tag.quizWidget.sendMessage({
            question:num,
            isLastQuestion:isLast
        });

        const quizWidget = p.tag.quizWidget;
        quizWidget.onMessage.Add(function(player, msg)
        {
            if(msg.type == "close" && player.tag.quizWidget == quizWidget)
            {
                WithStampResetState(player, function()
                {
                if(player.tag.quizWidget != quizWidget)
                    return;
                quizWidget.destroy();
                player.tag.quizWidget = null

                try
                {
                    if(msg.success)
                        UpdateStamp(player, idx - 1, msg.num);
                }
                finally
                {
                    ShowStampWidget(player);
                }
                });
            }
        });
    } 
}

// Admin commands remain private to their sender.
App.onSay.Add(function(player, text)
{
    if(typeof text != "string")
        return;
    const command = text.trim();
    if(command !== "/스탬프초기화" && command !== "/전체스탬프초기화")
        return;
    if(!IsStampResetAdmin(player))
    {
        player.sendMessage("관리자만 사용할 수 있는 명령어입니다.", 0xD35400);
        return;
    }
    if(!StampPlayerIsActive(player))
    {
        player.sendMessage("퀴즈 앱이 준비된 후 다시 입력해 주세요.", 0xD35400);
        return;
    }
    if(command === "/전체스탬프초기화")
    {
        let handled = false;
        player.showConfirm("이 스페이스의 전체 스탬프와 풀이 기록을 초기화합니다. 진행 중인 퀴즈는 종료되고, 미접속자도 다음 접속 시 초기화됩니다. 진행하시겠습니까?", function(result)
        {
            if(handled)
                return;
            handled = true;
            if(result !== false)
                BeginGlobalStampReset(player);
        });
        return;
    }
    WithStampResetState(player, function()
    {
        if(!IsStampResetAdmin(player))
            return;
        if(player.tag.quizWidget != null || player.tag.missionWidget != null)
        {
            player.sendMessage("퀴즈 또는 안내 창을 닫고 다시 입력해 주세요.", 0xD35400);
            return;
        }
        ResetStampProgress(player, _stampResetEpoch);
        player.sendMessage("본인의 스탬프 5개와 풀이 기록을 초기화했습니다.", 0x237A36);
    });
});
