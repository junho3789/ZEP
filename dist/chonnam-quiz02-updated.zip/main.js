
const SPRITE_BUTTON_RUN = App.loadSpritesheet("res/run.png");
const SetRun = (p) => 
{
    if(p.tag.isStun)
        return;

    if(p.tag.isRun) {
        p.tag.isRun = false;
        p.moveSpeed = 90;
    }
    else {
        p.tag.isRun = true;
        p.moveSpeed = 170;
    }

    p.sendUpdated();
}

App.addOnKeyDown(82, function (p) {
    SetRun(p);
});


const Alert = (p, msg, fontSize) => {
    if(p.tag.msgWidget  == null)
    {
        p.tag.msgWidget = p.showWidget("res/msg_widget.html", "top", 400, 120);
        p.tag.msgWidget.sendMessage({
            msg : msg,
            fontSize : fontSize,
            fontWeight : 700,
        });

        App.runLater(() => {
            if(_players.includes(p))
            {
                if(p.tag.msgWidget != null)
                {
                    p.tag.msgWidget.destroy();
                    p.tag.msgWidget = null;
                }
            }
        }, 3);
    }
}

const InitData = (p) =>
{
    p.tag.storage = {
        ver : 2,
        stamp: [false, false, false, false, false],
        questionNum : [0, 0, 0],
    }

    p.sendUpdated();
    SaveData(p);
}

const SaveData = (p) => 
{
    p.storage = JSON.stringify(p.tag.storage);
    p.save();
}

const LoadData = (p) =>
{
    p.tag.storage = JSON.parse(p.storage);
    if(p.tag.storage.ver < 2)
        InitData(p);
    else
        p.sendUpdated();
}

App.onInit.Add(function(){
    App.followPlayer = true;
    App.sendUpdated();
});

App.onStart.Add(function() 
{
    button = App.addMobileButton(8, 135, 45, function (p) 
    {
        SetRun(p);
    });

    button.image = SPRITE_BUTTON_RUN;
    button.sendUpdated();
});

let _players = [];
App.onJoinPlayer.Add(function(p) {
    p.tag = {
        isRun : false,
        storage : null,

        quizWidget : null,
        msgWidget : null,
        stampWidget : null,

        isEventView : false,
        eventWidget: null,
    }

    if(p.storage == null)
        InitData(p);
    else
        LoadData(p);

    if(p.isMobile)
        p.tag.stampWidget = p.showWidget("res/m_stamp.html", "topleft", 140, 100);
    else
        p.tag.stampWidget = p.showWidget("res/pc_stamp.html", "topleft", 240, 145);

    if(p.tag.stampWidget != null)
    {
        p.tag.stampWidget.sendMessage({
            stamp : p.tag.storage.stamp
        });
    }

    SetRun(p);
    _players.push(p);
});

App.addOnLocationTouched('Quiz01', function(p) 
{
    if(!p.tag.storage.stamp[0])
        OpenQuiz(p, 1);
});

App.onObjectTouched.Add(function(sender, x, y, object_effect_type, obj) 
{
    if(obj !== null && obj.type == ObjectEffectType.INTERACTION_WITH_ZEPSCRIPTS)
    {
        switch(obj.param1)
        {
             case "EventVideo":
                switch(obj.text)
                {
                    case "1":
                        EventWidget(sender);
                        break;
                    case "2":
                        if(sender.tag.isEventView)
                            sender.openWebLink("https://www.youtube.com/@aicoss_cnu", false);
                        else
                            Alert(sender, '영상을 시청하고 오세요.', 18);
                        break;
                }
                break;
            case "EventSNS":
                if(sender.tag.isEventView)
                    sender.openWebLink("https://www.instagram.com/jnu_aicoss/?utm_source=ig_web_button_share_sheet&igsh=MXZmdTlzeWJyNTZtOQ#1", false);
                else
                    Alert(sender, '영상을 시청하고 오세요.', 18);
                break;

            case "Quiz01":
                OpenQuiz(sender, 1, 0);
                break;
            case "Quiz02":
                if(sender.tag.storage.stamp[0])
                    OpenQuiz(sender, 2, obj.text);
                else
                    Alert(sender, "1번 로봇의 퀴즈를 먼저 풀고 오세요.", 18);
                break;
            case "Quiz03":
                let isLastQuestion = true;
                for(let i = 0; i < 4; i++)
                {
                    if(!sender.tag.storage.stamp[i])
                    {
                        isLastQuestion = false;
                        break;
                    }
                }

                if(isLastQuestion)
                    OpenQuiz(sender, 3, obj.text);
                else
                    Alert(sender, "1번, 2번 로봇의 퀴즈를 먼저 풀고 오세요.", 18);
                break;

        }
    }
});

App.onLeavePlayer.Add(function(p)
{
    _players = App.players;
});

const EventWidget = (p) =>
{
    if(p.tag.eventWidget == null)
    {
        if(p.isMobile)
            p.tag.eventWidget = p.showWidget("res/m_eventPopup.html", "middle", 340, 340);    
        else
            p.tag.eventWidget = p.showWidget("res/pc_eventPopup.html", "middle", 640, 640);    

        p.tag.eventWidget.onMessage.Add(function(player, msg)
        {
            if(msg.type == "close")
            {
                player.tag.eventWidget.destroy();
                player.tag.eventWidget = null

                player.tag.isEventView = msg.view;
            }
        });
    }
}

const UpdateStamp = (p, idx, num) =>
{
    switch(idx)
    {
        case 0:
            p.tag.storage.stamp[idx] = true;
            break;
        case 1:
            for(let i = 0; i < 3; i++)
            {
                if(p.tag.storage.questionNum[i] == num)
                    return;
            }

            for(let i = 1; i < 4; i++)
            {
                if(!p.tag.storage.stamp[i])
                {
                    p.tag.storage.questionNum[i - 1] = num;
                    p.tag.storage.stamp[i] = true;
                    break;
                }
            }
            break;
        case 2:
            p.tag.storage.stamp[4] = true;
            break;
    }
    if(p.tag.stampWidget != null)
    {
        p.tag.stampWidget.sendMessage({
            stamp : p.tag.storage.stamp
        });
    }

     SaveData(p);
}

const OpenQuiz = (p, idx, num) =>
{
   if(p.tag.quizWidget == null)
    {
        if(p.isMobile)
            p.tag.quizWidget = p.showWidgetResponsive(`res/pc_Quiz${idx}.html`, 0, 0, 0, 0);
        else
            p.tag.quizWidget = p.showWidgetResponsive(`res/pc_Quiz${idx}.html`, 0, 0, 0, 0);

        let isLast = true;
        for(let i = 1; i < 4; i++)
        {
            if(!p.tag.storage.stamp[i])
            {
                isLast = false;
                break;
            }
        }

        if(!isLast)
        {
            isLast = true;
            for(let i = 1; i < 3; i++)
            {
                if(!p.tag.storage.stamp[i] || p.tag.storage.questionNum[i - 1] == num)
                {
                    isLast = false;
                    break;
                }
            }
        }

        p.tag.quizWidget.sendMessage({
            question:num,
            isLastQuestion:isLast
        });

        p.tag.quizWidget.onMessage.Add(function(player, msg)
        {
            if(msg.type == "close")
            {
                player.tag.quizWidget.destroy();
                player.tag.quizWidget = null

                if(msg.success)
                    UpdateStamp(player, idx - 1, msg.num);
            }
        });
    } 
}
