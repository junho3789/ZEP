function LoadRunSprite(){try{return App.loadSpritesheet("res/run.png");}catch(error){return null;}}
const SPRITE_BUTTON_RUN = LoadRunSprite();
const STAMP_RESET_KEY = "quizStampResetEpoch";
let _players = [];
let _sessions = [];
let _stampResetEpoch = "0";
let _stampResetDestroyed = false;
let _syncRequest = null;
let _syncSerial = 0;
let _stampResetBusy = false;
let _widgetSerial = 0;
let _lastBackgroundSyncAttempt = 0;

function SafeNotice(player, text, color) {
    try { player.sendMessage(text, color == null ? 0xD35400 : color); } catch(error) {}
}
function SafeDestroy(widget, attempt) {
    if(widget == null) return;
    try { widget.destroy(); }
    catch(error) {
        if((attempt || 0) < 2) App.runLater(function() { SafeDestroy(widget, (attempt || 0) + 1); }, 0.5);
    }
}
function SamePlayer(a,b) {
    if(a === b)return true;
    return a != null && b != null && a.id != null && b.id != null && String(a.id) === String(b.id);
}
function GetSession(player) {
    return _sessions.find(function(s) { return s.active && SamePlayer(s.player,player) && player.tag === s.tag; }) || null;
}
function SessionActive(session) {
    return !_stampResetDestroyed && session != null && session.active && session.player.tag === session.tag;
}
function StampPlayerIsActive(player) {
    const s = GetSession(player);
    return SessionActive(s) && s.tag.storage != null;
}
function EpochTime(epoch) {
    if(typeof epoch !== "string" || !/^[0-9a-z]+-[0-9a-z]+$/i.test(epoch)) return 0;
    const time = parseInt(epoch.split("-")[0], 36);
    return Number.isSafeInteger(time) && time >= 1577836800000 && time <= Date.now()+86400000 ? time : 0;
}
function ProgressOrder(a, b) {
    const globalDifference = EpochTime(a.stampResetEpoch) - EpochTime(b.stampResetEpoch);
    if(globalDifference !== 0) return globalDifference;
    return (Number(a.stampPersonalResetAt) || 0) - (Number(b.stampPersonalResetAt) || 0);
}
function EmptyProgress() {
    return {ver:2, stamp:[false,false,false,false,false], questionNum:[0,0,0], stampResetEpoch:"0"};
}
function ParsePlayerData(raw) {
    if(raw == null || raw === "") return EmptyProgress();
    const data = JSON.parse(raw);
    if(data == null || typeof data !== "object" || Array.isArray(data)) throw new Error("Invalid player storage");
    if(data.stamp != null && !Array.isArray(data.stamp)) throw new Error("Invalid stamp storage");
    if(data.questionNum != null && !Array.isArray(data.questionNum)) throw new Error("Invalid question storage");
    data.stamp = Array.from({length:5}, function(_, i) { return Array.isArray(data.stamp) && data.stamp[i] === true; });
    const numbers = Array.isArray(data.questionNum) ? data.questionNum : [];
    data.questionNum = Array.from({length:3}, function(_, i) { const n=Number(numbers[i]); return Number.isInteger(n) && n >= 1 && n <= 39 ? n : 0; });
    data.ver = Math.max(2, Number(data.ver) || 0);
    data.stampResetEpoch = typeof data.stampResetEpoch === "string" ? data.stampResetEpoch : "0";
    return data;
}
function MergeProgress(current, stored, replace) {
    const order = ProgressOrder(current, stored);
    if(order < 0) return stored;
    const result = Object.assign({}, current, stored, {
        ver:Math.max(2, current.ver, stored.ver),
        stampResetEpoch:current.stampResetEpoch,
        stampPersonalResetAt:Number(current.stampPersonalResetAt) || 0
    });
    if(replace || order > 0) {
        result.stamp = current.stamp.slice(); result.questionNum = current.questionNum.slice();
        return result;
    }
    const numbers=[];
    current.questionNum.concat(stored.questionNum).forEach(function(n) {
        if(n >= 1 && n <= 39 && !numbers.includes(n) && numbers.length < 3) numbers.push(n);
    });
    const count = Math.min(3, Math.max(numbers.length, current.stamp.slice(1,4).filter(Boolean).length, stored.stamp.slice(1,4).filter(Boolean).length));
    result.stamp=[current.stamp[0] || stored.stamp[0], count>0, count>1, count>2, current.stamp[4] || stored.stamp[4]];
    result.questionNum=Array.from({length:3}, function(_, i) { return numbers[i] || 0; });
    return result;
}
function LoadData(player) {
    const s=GetSession(player);
    if(!SessionActive(s)) return false;
    try {
        s.tag.storage=ParsePlayerData(player.storage);
        s.readError=false;
        return true;
    } catch(error) {
        s.tag.storage=null;
        if(!s.readError) SafeNotice(player, "저장된 기록을 읽지 못했습니다. 기록은 초기화하지 않았습니다. 잠시 후 다시 시도해 주세요.");
        s.readError=true;
        return false;
    }
}
function SaveData(player, replace) {
    const s=GetSession(player);
    if(!SessionActive(s) || s.tag.storage == null) return false;
    try {
        const stored=ParsePlayerData(player.storage);
        const merged=MergeProgress(s.tag.storage, stored, replace === true);
        const previousRaw=player.storage;
        s.tag.storage=merged;
        player.storage=JSON.stringify(merged);
        try { player.save(); }
        catch(error) { player.storage=previousRaw; throw error; }
        s.dirty=false;
        return true;
    } catch(error) {
        if(!s.dirty) SafeNotice(player, "기록 저장을 재시도하고 있습니다. 저장된 기존 기록은 지우지 않습니다.");
        s.dirty=true;
        return false;
    }
}
function RefreshPlayerData(player) {
    const s=GetSession(player);
    if(!SessionActive(s)) return false;
    if(s.tag.storage == null) return LoadData(player);
    try { s.tag.storage=MergeProgress(s.tag.storage, ParsePlayerData(player.storage), false); }
    catch(error) { /* Keep the last readable record; never replace it with zeros. */ }
    return true;
}
function CloseOwnedWidget(session, key) {
    if(session == null) return;
    const meta=session.widgets[key];
    const widget=meta ? meta.widget : session.tag[key];
    delete session.widgets[key];
    session.tag[key]=null;
    if(meta) meta.closed=true;
    SafeDestroy(widget);
}
function ResetStampProgress(player, epoch, personal) {
    const s=GetSession(player);
    if(!SessionActive(s) || !RefreshPlayerData(player)) return false;
    CloseOwnedWidget(s, "quizWidget"); CloseOwnedWidget(s, "missionWidget");
    s.tag.storage.stamp=[false,false,false,false,false];
    s.tag.storage.questionNum=[0,0,0];
    s.tag.storage.stampResetEpoch=epoch;
    s.tag.storage.stampPersonalResetAt=personal || 0;
    const emptyRecord=player.storage == null || player.storage === "";
    const ok=emptyRecord && !personal ? true : SaveData(player, true);
    if(emptyRecord && !personal)s.dirty=false;
    CloseOwnedWidget(s, "stampWidget"); ShowStampWidget(player);
    return ok;
}
function ApplyStampResetEpoch(player) {
    const s=GetSession(player);
    if(!SessionActive(s) || !RefreshPlayerData(player)) return;
    // A missing/stale marker is NEVER a reset. Only a strictly newer positive revision may reset progress.
    if(EpochTime(_stampResetEpoch) > EpochTime(s.tag.storage.stampResetEpoch)) ResetStampProgress(player, _stampResetEpoch, 0);
}
function ReadStampResetStorage() {
    if(App.storage == null || App.storage === "") return {};
    const data=JSON.parse(App.storage);
    if(data == null || typeof data !== "object" || Array.isArray(data)) throw new Error("Invalid app storage");
    return data;
}
function ReadResetMarker(data) {
    // Legacy v2.7 markers are not sufficient authority to erase records during an upgrade.
    // Only the explicit, versioned reset record written after administrator confirmation is active.
    const state=data.quizStampResetState;
    if(state && state.version === 2 && typeof state.epoch === "string" && EpochTime(state.epoch)>0 && state.issuedAt === EpochTime(state.epoch))return state.epoch;
    return "0";
}
function SyncStampResetState(callback) {
    if(_stampResetDestroyed) return;
    if(_syncRequest != null) {
        if(typeof callback === "function") _syncRequest.callbacks.push(callback);
        return;
    }
    const request={id:++_syncSerial, callbacks:typeof callback === "function" ? [callback] : [], settled:false};
    _syncRequest=request;
    function finish(ok) {
        if(request.settled || _syncRequest !== request || _stampResetDestroyed) return;
        request.settled=true; _syncRequest=null;
        request.callbacks.forEach(function(fn) { try { fn(ok); } catch(error) { /* One obsolete callback must not block other players. */ } });
    }
    App.runLater(function() { finish(false); }, 8);
    try {
        App.getStorage(function() {
            if(request.settled || _syncRequest !== request || _stampResetDestroyed) return;
            try {
                const candidate=ReadResetMarker(ReadStampResetStorage());
                if(EpochTime(candidate) > EpochTime(_stampResetEpoch)) _stampResetEpoch=candidate;
                _sessions.slice().forEach(function(s) {
                    if(!SessionActive(s)) return;
                    ApplyStampResetEpoch(s.player);
                    if(s.dirty && s.tag.storage != null) SaveData(s.player, false);
                    ShowStampWidget(s.player);
                });
                finish(true);
            } catch(error) { finish(false); }
        });
    } catch(error) { finish(false); }
}
function WithStampResetState(player, callback) {
    const session=GetSession(player);
    if(!SessionActive(session) || !RefreshPlayerData(player)) return;
    ApplyStampResetEpoch(player);
    if(SessionActive(session)) callback();
    // Network latency must never keep a modal open or block ordinary play.
    RequestStampSync();
}
function RequestStampSync() {
    if(_stampResetDestroyed || Date.now()-_lastBackgroundSyncAttempt < 5000)return;
    _lastBackgroundSyncAttempt=Date.now();
    SyncStampResetState();
}
function PollStampResetState() {
    if(_stampResetDestroyed) return;
    _sessions.slice().forEach(function(session){
        if(!SessionActive(session) || !RefreshPlayerData(session.player))return;
        ApplyStampResetEpoch(session.player);
        if(session.dirty)SaveData(session.player,false);
        ShowStampWidget(session.player);
    });
    RequestStampSync();
    App.runLater(PollStampResetState, 15);
}
function SendWidgetInit(meta) {
    if(meta.closed || !SessionActive(meta.session) || meta.session.widgets[meta.key] !== meta) return;
    try { meta.widget.sendMessage(Object.assign({}, meta.payload, {type:"init", protocol:2, widgetSession:meta.id})); }
    catch(error) { /* The client will request initialization again when its listener is ready. */ }
}
function CreateManagedWidget(player, key, path, payload, closeHandler, fixed) {
    const session=GetSession(player);
    if(!SessionActive(session)) return null;
    let widget;
    try { widget=fixed ? player.showWidget(path, fixed.align, fixed.width, fixed.height) : player.showWidgetResponsive(path,0,0,0,0); }
    catch(error) { SafeNotice(player,"화면을 열지 못했습니다. 다시 시도해 주세요."); return null; }
    if(widget == null) return null;
    const meta={session:session, widget:widget, key:key, payload:payload, id:Date.now().toString(36)+"-"+(++_widgetSerial), ready:false, closed:false};
    session.widgets[key]=meta; session.tag[key]=widget;
    try {
        widget.onMessage.Add(function(sender, msg) {
            if(!SamePlayer(sender,player) || !SessionActive(session) || meta.closed || session.widgets[key] !== meta || !msg || typeof msg !== "object") return;
            if(msg.type === "ready") { SendWidgetInit(meta); return; }
            if(msg.type === "initialized" && msg.widgetSession === meta.id) {
                meta.ready=true;
                try { meta.widget.sendMessage({type:"confirmed",widgetSession:meta.id}); } catch(error) {}
                return;
            }
            if(msg.type === "close" && (msg.widgetSession === meta.id || (!meta.ready && msg.widgetSession == null && msg.success !== true))) {
                const mayAward=msg.widgetSession === meta.id && msg.success === true;
                CloseOwnedWidget(session,key);
                try { if(typeof closeHandler === "function") closeHandler(msg,mayAward); }
                catch(error) { SafeNotice(player,"결과 처리 중 연결이 지연됐습니다. 저장 상태를 확인해 주세요."); }
                finally { if(key === "quizWidget" || key === "missionWidget")ShowStampWidget(player); }
            }
        });
    } catch(error) { CloseOwnedWidget(session,key); return null; }
    SendWidgetInit(meta);
    App.runLater(function() {
        if(!SessionActive(session) || meta.closed || session.widgets[key] !== meta || meta.ready) return;
        CloseOwnedWidget(session,key);
        if(key !== "stampWidget") SafeNotice(player,"화면 연결이 지연되어 창을 닫았습니다. 다시 시도해 주세요.");
        ShowStampWidget(player);
    },25);
    return meta;
}
function ShowStampWidget(player) {
    const s=GetSession(player);
    if(!SessionActive(s) || s.tag.storage == null || s.tag.quizWidget != null || s.tag.missionWidget != null) return;
    const current=s.widgets.stampWidget;
    const signature=s.tag.storage.stamp.map(function(value){return value?"1":"0";}).join("");
    if(current && !current.closed) {
        if(current.ready && current.signature === signature)return;
        current.signature=signature;current.payload={stamp:s.tag.storage.stamp.slice()};SendWidgetInit(current);return;
    }
    const created=CreateManagedWidget(player,"stampWidget",player.isMobile ? "res/m_stamp.html" : "res/pc_stamp.html",{stamp:s.tag.storage.stamp.slice()},null,
        {align:"topleft",width:player.isMobile?196:244,height:player.isMobile?224:236});
    if(created)created.signature=signature;
}
function HideStampWidget(player) { CloseOwnedWidget(GetSession(player),"stampWidget"); }
function SetRun(player) {
    const s=GetSession(player); if(!SessionActive(s) || s.tag.isStun) return;
    s.tag.isRun=!s.tag.isRun; player.moveSpeed=s.tag.isRun?170:90; try{player.sendUpdated();}catch(error){}
}
function Alert(player, text, fontSize) { SafeNotice(player,text); }
function IsStampResetAdmin(player) { return player != null && typeof player.role === "number" && player.role >= 3000; }
function BeginGlobalStampReset(admin) {
    const session=GetSession(admin);
    if(!SessionActive(session) || !IsStampResetAdmin(admin)) return;
    if(_stampResetBusy) { SafeNotice(admin,"전체 초기화를 처리 중입니다. 잠시 기다려 주세요."); return; }
    _stampResetBusy=true;
    SyncStampResetState(function(ok) {
        if(!SessionActive(session) || !IsStampResetAdmin(admin)) { _stampResetBusy=false; return; }
        if(!ok) { _stampResetBusy=false; SafeNotice(admin,"초기화 기준을 읽지 못해 실행하지 않았습니다. 다시 시도해 주세요."); return; }
        let epoch;
        try {
            const data=ReadStampResetStorage();
            let time=Math.max(Date.now(),EpochTime(_stampResetEpoch)+1,EpochTime(data[STAMP_RESET_KEY])+1);
            _sessions.forEach(function(s) { if(SessionActive(s) && s.tag.storage) time=Math.max(time,EpochTime(s.tag.storage.stampResetEpoch)+1); });
            epoch=time.toString(36)+"-"+Math.random().toString(36).slice(2);
            data[STAMP_RESET_KEY]=epoch;
            data.quizStampResetState={version:2,epoch:epoch,issuedAt:time};
            App.setStorage(JSON.stringify(data));
        } catch(error) { _stampResetBusy=false; SafeNotice(admin,"전체 초기화를 저장하지 못했습니다. 기존 기록은 유지합니다."); return; }
        // Confirm with a fresh read, rather than treating a local assignment as proof of persistence.
        SyncStampResetState(function(verified) {
            _stampResetBusy=false;
            if(!SessionActive(session)) return;
            if(verified && EpochTime(_stampResetEpoch) >= EpochTime(epoch)) SafeNotice(admin,"전체 스탬프 초기화가 저장됐습니다. 다른 맵은 동기화 후, 미접속자는 다음 접속 시 적용됩니다.",0x237A36);
            else SafeNotice(admin,"전체 초기화 저장 결과를 아직 확인하지 못했습니다. 잠시 후 상태를 확인해 주세요.");
        });
    });
}
function OpenMissionNotice(player,target) {
    const s=GetSession(player);
    if(!SessionActive(s) || s.tag.quizWidget != null || s.tag.missionWidget != null) return;
    const meta=CreateManagedWidget(player,"missionWidget","res/mission_notice.html",{target:target,stamp:s.tag.storage.stamp.slice()},function(){ShowStampWidget(player);});
    if(meta) HideStampWidget(player);
}
function UpdateStamp(player,idx,num) {
    const s=GetSession(player); if(!SessionActive(s) || !RefreshPlayerData(player)) return;
    const data=s.tag.storage;
    if(idx===0) data.stamp[0]=true;
    else if(idx===1 && num>=1 && num<=39 && !data.questionNum.includes(num)) {
        for(let i=1;i<4;i++) if(!data.stamp[i]) { data.stamp[i]=true; data.questionNum[i-1]=num; break; }
    } else if(idx===2) data.stamp[4]=true;
    SaveData(player,false); ShowStampWidget(player);
}
function OpenQuiz(player,idx,num) {
    const s=GetSession(player);
    if(!SessionActive(s) || !RefreshPlayerData(player) || s.tag.quizWidget != null || s.tag.missionWidget != null) return;
    if(idx===2 && (!Number.isInteger(num) || num<1 || num>39)) { OpenMissionNotice(player,0); return; }
    const generation={stampResetEpoch:s.tag.storage.stampResetEpoch,stampPersonalResetAt:s.tag.storage.stampPersonalResetAt || 0};
    const count=s.tag.storage.stamp.slice(1,4).filter(Boolean).length;
    const isLast=idx===2 && (count>=3 || (count===2 && !s.tag.storage.questionNum.includes(num)));
    const meta=CreateManagedWidget(player,"quizWidget","res/pc_Quiz"+idx+".html",{question:num || 0,isLastQuestion:isLast},function(msg,mayAward) {
        // The window is already detached before ANY storage work is attempted.
        if(!SessionActive(s)) return;
        if(mayAward && s.tag.storage != null && ProgressOrder(s.tag.storage,generation)===0) UpdateStamp(player,idx-1,num);
        ShowStampWidget(player); RequestStampSync();
    });
    if(meta) HideStampWidget(player);
}
function EventWidget(player) {
    const s=GetSession(player); if(!SessionActive(s) || s.tag.eventWidget != null) return;
    CreateManagedWidget(player,"eventWidget",player.isMobile ? "res/m_eventPopup.html" : "res/pc_eventPopup.html",{},function(msg){s.tag.isEventView=msg.view===true;},
        {align:"middle",width:player.isMobile?340:640,height:player.isMobile?340:640});
}
App.addOnKeyDown(82,function(player){SetRun(player);});
App.onInit.Add(function(){App.followPlayer=true;App.sendUpdated();});
App.onStart.Add(function(){
    try{
        const button=App.addMobileButton(8,135,45,function(player){SetRun(player);});
        if(button != null){if(SPRITE_BUTTON_RUN != null)button.image=SPRITE_BUTTON_RUN;button.sendUpdated();}
    }catch(error){/* An optional mobile control must not terminate the quiz app. */}
    PollStampResetState();
});
App.onJoinPlayer.Add(function(player){
    _sessions.filter(function(s){return SamePlayer(s.player,player);}).forEach(function(s){
        s.active=false;Object.keys(s.widgets).forEach(function(key){CloseOwnedWidget(s,key);});
    });
    _sessions=_sessions.filter(function(s){return !SamePlayer(s.player,player);});
    _players=_players.filter(function(p){return !SamePlayer(p,player);});
    const tag={isRun:false,storage:null,quizWidget:null,missionWidget:null,msgWidget:null,stampWidget:null,eventWidget:null,isEventView:false};
    const session={player:player,tag:tag,active:true,widgets:{},dirty:false,readError:false};
    player.tag=tag;_sessions.push(session);_players.push(player);
    if(LoadData(player)) { ApplyStampResetEpoch(player);ShowStampWidget(player); }
    SetRun(player);RequestStampSync();
});
App.onLeavePlayer.Add(function(player){
    _sessions.filter(function(s){return SamePlayer(s.player,player);}).forEach(function(s){
        s.active=false;Object.keys(s.widgets).forEach(function(key){CloseOwnedWidget(s,key);});
    });
    _sessions=_sessions.filter(function(s){return s.active;});
    _players=_sessions.map(function(s){return s.player;});
});
App.onDestroy.Add(function(){
    _stampResetDestroyed=true;
    if(_syncRequest) {_syncRequest.settled=true;_syncRequest=null;}
    _sessions.forEach(function(s){s.active=false;Object.keys(s.widgets).forEach(function(key){CloseOwnedWidget(s,key);});});
    _sessions=[];_players=[];
});
App.addOnLocationTouched("Quiz01",function(player){WithStampResetState(player,function(){if(!player.tag.storage.stamp[0])OpenQuiz(player,1,0);});});
App.onSay.Add(function(player,text){
    if(typeof text!=="string")return;
    const command=text.trim();
    if(command!=="/스탬프초기화" && command!=="/전체스탬프초기화")return;
    if(!IsStampResetAdmin(player)){SafeNotice(player,"관리자만 사용할 수 있는 명령어입니다.");return;}
    const session=GetSession(player);
    if(!SessionActive(session) || !RefreshPlayerData(player)){SafeNotice(player,"저장된 기록을 확인한 뒤 다시 입력해 주세요.");return;}
    if(command==="/전체스탬프초기화"){
        let handled=false;
        player.showConfirm("이 스페이스의 전체 스탬프와 풀이 기록을 초기화합니다. 미접속자도 다음 접속 시 적용됩니다. 진행하시겠습니까?",function(result){
            if(handled)return;handled=true;
            if(result!==false && SessionActive(session) && IsStampResetAdmin(player))BeginGlobalStampReset(player);
        });return;
    }
    if(session.tag.quizWidget != null || session.tag.missionWidget != null){SafeNotice(player,"퀴즈 또는 안내 창을 닫고 다시 입력해 주세요.");return;}
    ApplyStampResetEpoch(player);
    const personal=Math.max(Date.now(),(Number(session.tag.storage.stampPersonalResetAt)||0)+1);
    if(ResetStampProgress(player,session.tag.storage.stampResetEpoch,personal))SafeNotice(player,"본인의 스탬프 5개와 풀이 기록을 초기화했습니다.",0x237A36);
});

const QUIZ_COURSE_NUMBERS = {"컴퓨팅사고와sw코딩": 1, "문제해결과알고리즘": 2, "프로그래밍기초와실습": 3, "인공지능기초와활용v2": 4, "데이터분석기초": 5, "인공지능수학기초": 6, "ai알고리즘": 7, "기계학습": 8, "딥러닝": 9, "지능hci": 10, "인공지능시스템": 11, "인공지능수학심화": 12, "ai클라우드컴퓨팅": 13, "강화학습v2": 14, "자연어처리": 15, "음성인식": 16, "영상이해": 17, "비지도학습": 18, "지식표현과추론": 19, "r기초와데이터마트": 20, "ai데이터분석": 21, "첨단심층신경망": 22, "피지컬ai시뮬레이션": 23, "ai모빌리티센서": 24, "강화학습특론": 25, "컴퓨터비전": 26, "뇌인지공학개론": 27, "자율주행": 28, "자료구조와알고리즘1": 29, "인공지능산업": 30, "행정빅데이터분석론": 31, "ai교육데이터의이해와활용": 32, "도시데이터사이언스입문": 33, "ai와스토리텔링": 34, "인공지능시대와ai윤리": 35, "생성형ai기초": 36, "에너지ai": 37, "지능로봇": 38, "iot컴퓨팅": 39};
const ResolveQuizQuestion = (value) =>
{
    const text = String(value == null ? "" : value).trim();
    const key = text.replace(/\s+/g, "").toLowerCase();
    if(Object.prototype.hasOwnProperty.call(QUIZ_COURSE_NUMBERS, key))
        return QUIZ_COURSE_NUMBERS[key];
    const match = key.match(/^(?:quiz)?0*(\d{1,2})(?:번)?$/);
    if(match == null)
        return null;
    const number = Number(match[1]);
    return number >= 1 && number <= 39 ? number : null;
}


App.onObjectTouched.Add(function(sender, x, y, object_effect_type, obj) 
{
    if(obj != null && typeof obj === "object" && obj.type == ObjectEffectType.INTERACTION_WITH_ZEPSCRIPTS)
    {
        WithStampResetState(sender, function()
        {
        const rawAction = String(obj.param1 == null ? "" : obj.param1).trim();
        const actions = {quiz01:"Quiz01", quiz02:"Quiz02", quiz03:"Quiz03", eventvideo:"EventVideo", eventsns:"EventSNS"};
        const action = actions[rawAction.toLowerCase()] || (ResolveQuizQuestion(rawAction) != null ? "Quiz02" : rawAction);
        switch(action)
        {
             case "EventVideo":
                switch(obj.text)
                {
                    case "1":
                        EventWidget(sender);
                        break;
                    case "2":
                        if(sender.tag.isEventView)
                            sender.openWebLink("https://www.youtube.com/@aicoss_cnu", false);
                        else
                            Alert(sender, '영상을 시청하고 오세요.', 18);
                        break;
                }
                break;
            case "EventSNS":
                if(sender.tag.isEventView)
                    sender.openWebLink("https://www.instagram.com/jnu_aicoss/?utm_source=ig_web_button_share_sheet&igsh=MXZmdTlzeWJyNTZtOQ#1", false);
                else
                    Alert(sender, '영상을 시청하고 오세요.', 18);
                break;

            case "Quiz01":
                OpenQuiz(sender, 1, 0);
                break;
            case "Quiz02":
                if(sender.tag.storage.stamp[0])
                {
                    let questionNum = ResolveQuizQuestion(obj.text);
                    if(questionNum == null)
                        questionNum = ResolveQuizQuestion(obj.param2);
                    if(questionNum == null && !Object.prototype.hasOwnProperty.call(actions, rawAction.toLowerCase()))
                        questionNum = ResolveQuizQuestion(rawAction);
                    if(questionNum != null)
                        OpenQuiz(sender, 2, questionNum);
                    else
                        OpenMissionNotice(sender, 0);
                }
                else
                    OpenMissionNotice(sender, 2);
                break;
            case "Quiz03":
                let isLastQuestion = true;
                for(let i = 0; i < 4; i++)
                {
                    if(!sender.tag.storage.stamp[i])
                    {
                        isLastQuestion = false;
                        break;
                    }
                }

                if(isLastQuestion)
                    OpenQuiz(sender, 3, obj.text);
                else
                    OpenMissionNotice(sender, 3);
                break;

        }
        });
    }
});
