// Public, non-secret map settings. IDs must match the administrator's persona IDs.
var NPC_CONFIG = {
    stopRadius: 2,
    resumeRadius: 4,
    // Original attached sheet will replace this preview asset once available as a PNG file.
    sprite: { file: "npc.png", frameWidth: 32, frameHeight: 48, frameRate: 6,
        animations: { down: [0, 1, 2], left: [3, 4, 5], right: [6, 7, 8], up: [9, 10, 11],
            down_idle: [1], left_idle: [4], right_idle: [7], up_idle: [10] } },
    characters: [
        { id: "moa", name: "모아", style: "friendly", x: 8, y: 8, minX: 3, maxX: 16, minY: 3, maxY: 16 },
        { id: "sage", name: "서가", style: "calm", x: 12, y: 8, minX: 3, maxX: 16, minY: 3, maxY: 16 }
    ]
};

/* Platform-independent controller. Coordinates are integer tiles.
 * Adapter must use authoritative positions and validate collision at every step.
 */
function NpcController(adapter, config) {
  this.a=adapter;
  this.c=Object.assign({stopRadius:2,resumeRadius:4,stepSeconds:0.55,minX:0,maxX:20,minY:0,maxY:20},config);
  if (this.c.resumeRadius<=this.c.stopRadius) throw new Error('resumeRadius must exceed stopRadius');
  this.state='roaming'; this.timer=0; this.direction=null; this.steps=0;
  this.sessions={};
}
NpcController.prototype.distance=function(p,q) { return Math.max(Math.abs(p.x-q.x),Math.abs(p.y-q.y)); };
NpcController.prototype.tick=function(dt) {
  var a=this.a,c=this.c,npc=a.position(),players=a.players(),nearest=Infinity;
  for(var i=0;i<players.length;i++) nearest=Math.min(nearest,this.distance(npc,players[i]));
  for(var id in this.sessions) {
    var found=players.find(function(p){return String(p.id)===id;});
    if(!found || this.distance(npc,found)>c.resumeRadius) { a.closeChat(id); delete this.sessions[id]; }
  }
  if(this.state==='roaming' && nearest<=c.stopRadius) { this.state='waiting'; this.steps=0; a.stop(); }
  if(this.state==='waiting' && nearest>c.resumeRadius) { this.state='roaming'; this.timer=0.5; }
  if(this.state!=='roaming') return;
  this.timer-=dt;
  if(this.timer>0) return;
  if(this.steps<=0) {
    var dirs=[[1,0],[-1,0],[0,1],[0,-1]];
    this.direction=dirs[Math.floor(Math.random()*dirs.length)];
    this.steps=2+Math.floor(Math.random()*4);
    this.timer=0.5+Math.random()*1.5;
    return;
  }
  var x=npc.x+this.direction[0],y=npc.y+this.direction[1];
  if(x<c.minX || x>c.maxX || y<c.minY || y>c.maxY || !a.canWalk(x,y)) {this.steps=0;this.timer=0.3;return;}
  a.step(x,y,c.stepSeconds); this.steps--; this.timer=c.stepSeconds;
};
NpcController.prototype.interact=function(player) {
  if(this.distance(this.a.position(),player)>this.c.stopRadius) return false;
  this.state='waiting'; this.a.stop(); this.sessions[String(player.id)]=true; this.a.openChat(player); return true;
};
NpcController.prototype.close=function(id) {delete this.sessions[String(id)];};
if(typeof module!=='undefined') module.exports=NpcController;

/* Deterministic local conversation engine. No network or generated answers. */
var NpcDialogue = (function () {
    "use strict";
    var STYLES = {
        friendly: { label: "친근한 반말", greet: ["안녕, {player}! 나는 {name}야. 만나서 반가워!", "반가워! 나는 {name}야. 무슨 이야기 할까?"], unknown: ["그건 아직 잘 모르겠어. 다른 말로 조금만 더 알려줄래?", "내가 아는 건 소개, 산책, 이 공간 이야기야. 어떤 게 궁금해?"],
            intro: ["나는 {name}야. {personality}", "{name}라고 불러줘! {background}"],
            walk: ["잠깐 산책하고 있었어. 같이 걸을래?", "주변을 둘러보는 중이야. 너도 같이 산책할래?"], yes: ["좋아! 이야기 끝나고 주변을 천천히 둘러보자.", "좋아, 서두르지 말고 쉬엄쉬엄 구경하자!"], no: ["괜찮아! 여기서 잠깐 이야기해도 좋아.", "그럼 잠깐 쉬자. 무슨 이야기를 해볼까?"],
            thanks: ["도움이 됐다니 기뻐!", "언제든 편하게 말 걸어줘."], bye: ["또 만나! 좋은 시간 보내.", "잘 가! 다음에 또 이야기하자."], feeling: ["그랬구나. 지금 마음이 어떤지 조금 더 이야기해 줄래?", "편하게 이야기해도 괜찮아. 무슨 일이 있었어?"],
            book: ["좋아하는 장르부터 이야기해 볼까? 모험, 추리, 편안한 이야기 중에 어떤 게 좋아?"], follow: ["조금 더 궁금한 부분을 구체적으로 말해줄래?", "내가 아는 범위에서 같이 이야기해보자."] },
        polite: { label: "다정한 존댓말", greet: ["안녕하세요, {player}님. 저는 {name}예요. 만나서 반가워요.", "반가워요. 저는 {name}예요. 어떤 이야기를 해볼까요?"], unknown: ["그 내용은 아직 잘 모르겠어요. 조금 다른 표현으로 말씀해 주실래요?", "소개나 산책, 이 공간에 관해서는 이야기할 수 있어요. 어떤 것이 궁금하세요?"],
            intro: ["저는 {name}예요. {personality}", "제 이름은 {name}예요. {background}"], walk: ["주변을 천천히 산책하고 있었어요. 같이 걸으실래요?"], yes: ["좋아요. 이야기를 마친 뒤 주변을 천천히 둘러보세요."], no: ["괜찮아요. 여기서 잠깐 쉬며 이야기해요."],
            thanks: ["도움이 되었다니 기뻐요.", "언제든 편하게 말씀해 주세요."], bye: ["다음에 또 만나요. 편안한 시간 보내세요."], feeling: ["그런 일이 있었군요. 괜찮으시면 조금 더 이야기해 주실래요?"], book: ["어떤 장르를 좋아하세요? 모험, 추리, 편안한 이야기 중에서 골라보셔도 좋아요."], follow: ["어떤 부분이 더 궁금하신가요? 조금 더 구체적으로 말씀해 주세요."] },
        playful: { label: "발랄한 말투", greet: ["짜잔! {name} 등장! {player}, 반가워!", "어서 와, {player}! 나는 {name}야. 오늘은 무슨 이야기 할까?"], unknown: ["앗, 그건 내 대화 노트에 아직 없어! 다른 말로 알려줄래?", "음, 그건 모르겠어! 대신 소개나 산책 이야기는 어때?"],
            intro: ["내 이름은 {name}! {personality}", "나는 {name}야! {background}"], walk: ["다음 산책 코스를 고민 중이었어! 같이 걸을래?"], yes: ["좋아 좋아! 이야기 끝나면 주변부터 구경해보자!"], no: ["좋아, 그럼 쉬는 시간! 여기서 수다 떨자."],
            thanks: ["헤헤, 도움이 됐다니 뿌듯한걸!"], bye: ["다음에 또 놀러 와! 기다릴게!"], feeling: ["그랬구나. 어떤 일이 있었는지 나한테 이야기해줄래?"], book: ["책 이야기 좋지! 모험, 추리, 편안한 이야기 중에 뭐가 끌려?"], follow: ["조금 더 자세히 말해줘! 어떤 부분이 궁금해?"] },
        calm: { label: "차분한 존댓말", greet: ["어서 오세요, {player}님. 저는 {name}입니다.", "반갑습니다. 저는 {name}입니다. 천천히 이야기 나눠요."], unknown: ["제가 아는 이야기에는 없는 내용입니다. 다른 표현으로 말씀해 주시겠어요?", "소개, 산책, 이 공간 안내 중에서 이야기를 이어갈 수 있습니다."],
            intro: ["제 이름은 {name}입니다. {personality}", "저는 {name}입니다. {background}"], walk: ["잠시 주변을 걷고 있었습니다. 함께 걸으시겠어요?"], yes: ["좋습니다. 대화를 마친 뒤 천천히 주변을 둘러보세요."], no: ["알겠습니다. 여기서 잠시 쉬어 가셔도 좋습니다."],
            thanks: ["도움이 되었다니 다행입니다."], bye: ["편안한 시간 보내세요. 다음에 또 뵙겠습니다."], feeling: ["그런 일이 있었군요. 마음이 괜찮으시다면 조금 더 들려주세요."], book: ["좋아하는 이야기의 분위기가 있으신가요? 모험, 추리, 편안한 이야기 중에서 골라보세요."], follow: ["어떤 부분이 궁금하신지 조금 더 구체적으로 말씀해 주세요."] }
    };
    function own(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
    function clone(o) { return JSON.parse(JSON.stringify(o)); }
    function rule(id, title, words, replies, extra) {
        var r = { id: id, title: title, keywords: words, replies: replies, followUps: [], acceptReplies: [], declineReplies: [] };
        if (extra) Object.keys(extra).forEach(function (key) { r[key] = extra[key]; });
        return r;
    }
    function defaults(id, style) {
        style = own(STYLES, style) ? style : "friendly";
        var s = STYLES[style], book = id === "sage";
        return { name: book ? "서가" : "모아", personality: book ? "차분하게 이야기를 듣고 책을 좋아하는 친구예요." : "호기심이 많고 산책과 대화를 좋아하는 친구야.",
            background: "이 공간에서 산책하고 쉬어 가는 친구들과 이야기를 나누고 있어요.",
            style: style, revision: 1, greetings: clone(s.greet), fallbacks: clone(s.unknown), rules: [
                rule("builtin_hello", "인사", ["안녕", "반가워", "반갑", "hello", "hi"], clone(s.greet)),
                rule("builtin_intro", "자기소개", ["누구", "이름", "소개", "넌뭐", "너는뭐"], clone(s.intro), { followUps: clone(s.follow) }),
                rule("builtin_walk", "산책", ["뭐해", "뭐하고", "산책", "걷고", "같이걷"], clone(s.walk), { acceptReplies: clone(s.yes), declineReplies: clone(s.no), followUps: clone(s.follow) }),
                rule("builtin_place", "공간 안내", ["여기어디", "어떤공간", "공간안내", "장소안내", "여기는"], ["{background}"], { followUps: clone(s.follow) }),
                rule("builtin_thanks", "감사", ["고마워", "고맙", "감사", "thanks", "thank you"], clone(s.thanks)),
                rule("builtin_bye", "작별", ["잘가", "잘있어", "안녕히", "다음에봐", "또만나", "bye"], clone(s.bye)),
                rule("builtin_feeling", "마음 이야기", ["슬퍼", "슬프", "속상", "힘들", "외로", "기분"], clone(s.feeling), { followUps: clone(s.feeling) }),
                rule("builtin_book", "책 이야기", ["책추천", "책이야기", "독서", "좋아하는책", "읽을책"], clone(s.book), { followUps: clone(s.follow) })
            ] };
    }
    function text(v, max) { return typeof v === "string" && v.trim().length > 0 && v.length <= max; }
    function list(v, min, max, length) {
        return Array.isArray(v) && v.length >= min && v.length <= max && v.every(function (x) { return text(x, length); });
    }
    function validate(input) {
        if (!input || typeof input !== "object" || !text(input.name, 40) || !text(input.personality, 500) || !text(input.background, 1000) ||
            !own(STYLES, input.style) || !list(input.greetings, 1, 8, 500) || !list(input.fallbacks, 1, 8, 500) ||
            !Array.isArray(input.rules) || input.rules.length > 30) return { error: "이름·성격·배경·인사말·말투를 확인해 주세요." };
        var ids = {}, rules = [];
        for (var i = 0; i < input.rules.length; i++) {
            var r = input.rules[i];
            if (!r || typeof r.id !== "string" || !/^[a-z][a-z0-9_]{0,63}$/.test(r.id) || own(ids, r.id) || !text(r.title, 40) ||
                !list(r.keywords, 1, 20, 40) || r.keywords.some(function (k) { return compact(k).length < 2; }) ||
                !list(r.replies, 1, 8, 500) || !list(r.followUps || [], 0, 8, 500) || !list(r.acceptReplies || [], 0, 8, 500) || !list(r.declineReplies || [], 0, 8, 500)) {
                return { error: "주제 " + (i + 1) + ": 이름, 중복 ID, 2자 이상 키워드, 답변을 확인해 주세요." };
            }
            if (!!(r.acceptReplies || []).length !== !!(r.declineReplies || []).length) return { error: "동의·거절 답변은 둘 다 입력하거나 둘 다 비워 주세요." };
            ids[r.id] = true;
            rules.push({ id: r.id, title: r.title.trim(), keywords: r.keywords.map(function (x) { return x.trim(); }),
                replies: r.replies.slice(), followUps: (r.followUps || []).slice(), acceptReplies: (r.acceptReplies || []).slice(), declineReplies: (r.declineReplies || []).slice() });
        }
        return { value: { name: input.name.trim(), personality: input.personality.trim(), background: input.background.trim(), style: input.style,
            greetings: input.greetings.slice(), fallbacks: input.fallbacks.slice(), rules: rules, revision: 1 } };
    }
    function normalize(s) {
        if (typeof s.normalize === "function") s = s.normalize("NFKC");
        return s.toLowerCase().replace(/[.,!?~…。，！？ㅋㅎㅠㅜ:;"'“”‘’()[\]{}<>/\\_-]+/g, " ").replace(/\s+/g, " ").trim();
    }
    function compact(s) { return normalize(s).replace(/\s/g, ""); }
    function keywordMatches(message, key) {
        if (/^[a-z0-9 ]+$/i.test(key)) {
            var escaped = normalize(key).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
            return new RegExp("(^|[^a-z0-9])" + escaped + "($|[^a-z0-9])").test(normalize(message));
        }
        return compact(message).indexOf(compact(key)) !== -1;
    }
    function fresh() { return { lastTopic: null, awaiting: null, used: {}, lastIndex: {}, unknown: 0 }; }
    function pick(values, key, state, random) {
        var used = own(state.used, key) ? state.used[key] : [], last = state.lastIndex[key];
        if (used.length >= values.length) used = [];
        var choices = [];
        for (var i = 0; i < values.length; i++) if (used.indexOf(i) < 0 && (values.length === 1 || i !== last)) choices.push(i);
        if (!choices.length) for (var j = 0; j < values.length; j++) if (used.indexOf(j) < 0) choices.push(j);
        var index = choices[Math.min(choices.length - 1, Math.floor((random || Math.random)() * choices.length))];
        used.push(index); state.used[key] = used; state.lastIndex[key] = index;
        return values[index];
    }
    function format(s, p, playerName) {
        var vars = { name: p.name, player: playerName || "친구", personality: p.personality, background: p.background };
        return s.replace(/\{(name|player|personality|background)\}/g, function (_, k) { return vars[k]; });
    }
    function greeting(p, state, playerName, random) { return format(pick(p.greetings, "greeting", state, random), p, playerName); }
    function reply(p, message, state, playerName, random) {
        var key = compact(message), current = p.rules.filter(function (r) { return r.id === state.lastTopic; })[0], previous = state.awaiting;
        var yes = ["응", "네", "넵", "좋아", "좋아요", "그래", "그래요", "같이가자", "같이걸을래", "yes", "ok", "okay"];
        var no = ["아니", "아니요", "아니야", "싫어", "싫어요", "괜찮아", "괜찮아요", "다음에", "no"];
        if (current && previous === current.id && (yes.indexOf(key) >= 0 || no.indexOf(key) >= 0)) {
            state.awaiting = null; state.unknown = 0;
            var accepted = yes.indexOf(key) >= 0;
            return format(pick(accepted ? current.acceptReplies : current.declineReplies, current.id + (accepted ? ":yes" : ":no"), state, random), p, playerName);
        }
        if (current && ["더알려줘", "자세히알려줘", "더말해줘", "왜", "왜요", "어떻게", "어떻게요"].indexOf(key) >= 0 && current.followUps.length) {
            state.awaiting = null; state.unknown = 0;
            return format(pick(current.followUps, current.id + ":follow", state, random), p, playerName);
        }
        var best = null, score = -1;
        p.rules.forEach(function (r) { r.keywords.forEach(function (word) {
            var length = compact(word).length;
            if (keywordMatches(message, word) && length > score) { best = r; score = length; }
        }); });
        state.awaiting = null;
        if (best) {
            state.lastTopic = best.id; state.unknown = 0;
            if (best.acceptReplies.length && best.declineReplies.length) state.awaiting = best.id;
            return format(pick(best.replies, best.id, state, random), p, playerName);
        }
        state.unknown++;
        // Unknown messages do not keep an old topic alive indefinitely.
        if (state.unknown >= 2) state.lastTopic = null;
        return format(pick(p.fallbacks, "unknown", state, random), p, playerName);
    }
    return { styles: Object.keys(STYLES).map(function (id) { return { id: id, label: STYLES[id].label }; }),
        defaults: defaults, validate: validate, fresh: fresh, reply: reply, greeting: greeting, clone: clone };
}());
if (typeof module !== "undefined") module.exports = NpcDialogue;

/* ZEP runtime adapter. build.py prepends config, controller and dialogue engine. */
(function () {
    "use strict";
    var npcs = [], chats = {}, editors = {}, conversations = {}, clock = 0;
    var personas = {}, storeRevision = 0, storageReady = false, storageError = "", saving = false;
    var STORE_KEY = "aiNpcOfflineV2";
    function admin(p) { return p && (p.role === 3000 || p.role === 3001); }
    function player(id) {
        for (var i = 0; i < App.players.length; i++) if (String(App.players[i].id) === String(id)) return App.players[i];
        return null;
    }
    function position(n) {
        var o = Map.getObjectWithKey(n.key);
        return { x: o.tileX, y: o.tileY };
    }
    function distance(n, p) {
        var q = position(n);
        return Math.max(Math.abs(q.x - p.tileX), Math.abs(q.y - p.tileY));
    }
    function close(id) {
        var c = chats[id];
        if (!c) return;
        delete chats[id]; // Invalidate callbacks before destroying the widget.
        c.npc.controller.close(id);
        c.widget.destroy();
    }
    function record(id, npc) {
        var key = String(id) + ":" + npc.id, persona = personas[npc.id], entry = conversations[key];
        if (!entry || entry.revision !== persona.revision || clock - entry.touched > 1800) {
            if (Object.keys(conversations).length >= 500) {
                var oldest = Object.keys(conversations).sort(function (a, b) { return conversations[a].touched - conversations[b].touched; })[0];
                delete conversations[oldest];
            }
            entry = { revision: persona.revision, state: NpcDialogue.fresh(), history: [], touched: clock };
            conversations[key] = entry;
        }
        entry.touched = clock;
        return entry;
    }
    function suggestions(persona) {
        return persona.rules.filter(function (r) { return r.id !== "builtin_hello" && r.id !== "builtin_bye" && r.id !== "builtin_thanks"; })
            .slice(0, 5).map(function (r) { return { label: r.title, message: r.keywords[0] }; });
    }
    function open(n, p) {
        var id = String(p.id);
        if (!storageReady) { p.sendMessage(storageError || "캐릭터 설정을 불러오고 있어요. 잠시 후 다시 말 걸어 주세요."); return; }
        if (chats[id] && chats[id].npc === n) return;
        close(id);
        var w = p.showWidgetResponsive("chat.html", 12, p.isMobile ? 3 : 28, 12, p.isMobile ? 3 : 28);
        var c = { npc: n, widget: w, pending: null, last: -100, initialized: false };
        chats[id] = c;
        w.onMessage.Add(function (sender, data) {
            if (String(sender.id) !== id || chats[id] !== c || !data || typeof data !== "object") return;
            if (data.type === "npc.close") { close(id); return; }
            if (distance(n, sender) > NPC_CONFIG.resumeRadius) { close(id); return; }
            if (data.type === "npc.editor" && admin(sender)) { close(id); openEditor(sender); return; }
            var persona = personas[n.id];
            if (!persona) return;
            if (data.type === "npc.ready") {
                if (!c.initialized) {
                    c.initialized = true;
                    var saved = record(id, n);
                    if (!saved.history.length) saved.history.push({ role: "assistant", text: NpcDialogue.greeting(persona, saved.state, sender.name) });
                    w.sendMessage({ type: "npc.init", name: persona.name, history: saved.history, suggestions: suggestions(persona), canEdit: admin(sender) });
                }
                return;
            }
            if (data.type !== "npc.chat" || typeof data.requestId !== "string" || data.requestId.length > 100) return;
            function error(text) { w.sendMessage({ type: "npc.reply", requestId: data.requestId, error: text }); }
            if (typeof data.message !== "string" || !data.message.trim() || data.message.length > 1000) { error("메시지는 1~1000자로 입력해 주세요."); return; }
            if (c.pending || clock - c.last < 0.6) { error("잠시만 기다려 주세요."); return; }
            c.pending = data.requestId; c.last = clock;
            App.runLater(function () {
                if (chats[id] !== c || c.pending !== data.requestId) return;
                c.pending = null;
                var current = player(id);
                if (!current || distance(n, current) > NPC_CONFIG.resumeRadius) { close(id); return; }
                var live = personas[n.id], entry = record(id, n);
                var answer = NpcDialogue.reply(live, data.message.trim(), entry.state, current.name);
                entry.history.push({ role: "user", text: data.message.trim() }, { role: "assistant", text: answer });
                entry.history = entry.history.slice(-40);
                w.sendMessage({ type: "npc.reply", requestId: data.requestId, answer: answer, name: live.name, suggestions: suggestions(live) });
            }, 0.35);
        });
    }
    function parseRoot(raw) {
        var root = JSON.parse(raw || "{}");
        if (!root || typeof root !== "object" || Array.isArray(root)) throw new Error("Invalid storage");
        return root;
    }
    function readPack(root) {
        var saved = root[STORE_KEY];
        if (!saved) {
            saved = { schema: 2, revision: 0, personas: {} };
            NPC_CONFIG.characters.forEach(function (def) { saved.personas[def.id] = NpcDialogue.defaults(def.id, def.style || "friendly"); });
        }
        if (saved.schema !== 2 || !Number.isInteger(saved.revision) || saved.revision < 0 || !saved.personas || typeof saved.personas !== "object" || Array.isArray(saved.personas)) throw new Error("Invalid persona storage");
        var validated = {};
        NPC_CONFIG.characters.forEach(function (def) {
            var value = Object.prototype.hasOwnProperty.call(saved.personas, def.id) ? saved.personas[def.id] : NpcDialogue.defaults(def.id, def.style);
            var check = NpcDialogue.validate(value);
            if (check.error || !Number.isInteger(value.revision) || value.revision < 1) throw new Error("Invalid saved persona");
            check.value.revision = value.revision;
            validated[def.id] = check.value;
        });
        return { schema: 2, revision: saved.revision, personas: validated };
    }
    function applyPack(pack) {
        personas = pack.personas; storeRevision = pack.revision; storageReady = true; storageError = "";
        npcs.forEach(function (n) {
            n.name = personas[n.id].name;
            if (n.object && n.object.npcProperty) {
                n.object.npcProperty.name = n.name;
                if (typeof n.object.sendUpdated === "function") n.object.sendUpdated();
            }
        });
    }
    function load(done) {
        App.getStorage(function (raw) {
            try { applyPack(readPack(parseRoot(raw))); if (done) done(null); }
            catch (e) { storageError = "저장된 캐릭터 설정을 읽지 못했어요. 관리자에게 알려 주세요."; if (done) done(storageError); }
        });
    }
    function openEditor(p) {
        if (!admin(p)) return;
        var id = String(p.id);
        if (editors[id]) { editors[id].destroy(); delete editors[id]; }
        var w = p.showWidgetResponsive("editor.html", 3, p.isMobile ? 2 : 12, 3, p.isMobile ? 2 : 12);
        editors[id] = w;
        w.onMessage.Add(function (sender, data) {
            if (String(sender.id) !== id || editors[id] !== w || !data || typeof data !== "object") return;
            if (!admin(sender)) { w.destroy(); delete editors[id]; return; }
            if (data.type === "editor.close") { w.destroy(); delete editors[id]; return; }
            function send(payload) { if (editors[id] === w) w.sendMessage(payload); }
            if (data.type === "editor.ready" || data.type === "editor.reload") {
                load(function (err) {
                    if (err) send({ type: "editor.error", error: err });
                    else send({ type: "editor.init", personas: personas, revision: storeRevision, styles: NpcDialogue.styles });
                });
                return;
            }
            if (data.type === "editor.preset") {
                if (!Object.prototype.hasOwnProperty.call(personas, data.npcId) || !NpcDialogue.styles.some(function (s) { return s.id === data.style; })) return;
                send({ type: "editor.preset", preset: NpcDialogue.defaults(data.npcId, data.style) });
                return;
            }
            if (data.type !== "editor.save") return;
            if (saving) { send({ type: "editor.error", error: "다른 저장을 처리 중이에요. 잠시 후 다시 시도해 주세요." }); return; }
            if (typeof data.npcId !== "string" || !Object.prototype.hasOwnProperty.call(personas, data.npcId)) return;
            var check = NpcDialogue.validate(data.persona);
            if (check.error) { send({ type: "editor.error", error: check.error }); return; }
            saving = true;
            App.getStorage(function (raw) {
                if (!admin(sender) || editors[id] !== w) { saving = false; return; }
                try {
                    var root = parseRoot(raw), pack = readPack(root);
                    if (pack.revision !== data.expectedRevision) { saving = false; send({ type: "editor.error", error: "다른 수정 내용이 있어요. 다시 불러온 뒤 저장해 주세요." }); return; }
                    check.value.revision = pack.personas[data.npcId].revision + 1;
                    pack.personas[data.npcId] = check.value; pack.revision++;
                    root[STORE_KEY] = pack;
                    var serialized = JSON.stringify(root);
                    if (serialized.length > 50000) { saving = false; send({ type: "editor.error", error: "설정이 너무 커요. 대사 수나 길이를 줄여 주세요." }); return; }
                    App.setStorage(serialized);
                    function verify(attempt) {
                        App.getStorage(function (latest) {
                            try {
                                var confirmed = readPack(parseRoot(latest));
                                if (confirmed.revision === pack.revision && JSON.stringify(confirmed.personas) === JSON.stringify(pack.personas)) {
                                    applyPack(confirmed); saving = false;
                                    // Existing conversation state resets on next record() by revision.
                                    Object.keys(chats).forEach(function (uid) { if (chats[uid].npc.id === data.npcId) close(uid); });
                                    send({ type: "editor.saved", personas: personas, revision: storeRevision });
                                } else if (attempt < 2) App.runLater(function () { verify(attempt + 1); }, 0.5);
                                else { saving = false; send({ type: "editor.error", error: "저장 확인이 지연되고 있어요. 다시 불러와 확인해 주세요." }); }
                            } catch (e) { saving = false; send({ type: "editor.error", error: "저장 결과를 확인하지 못했어요." }); }
                        });
                    }
                    verify(0);
                } catch (e) { saving = false; send({ type: "editor.error", error: "설정을 저장하지 못했어요. 저장된 데이터를 확인해 주세요." }); }
            });
        });
    }
    function canWalk(n, x, y) {
        if (x < 0 || y < 0 || x >= Map.width || y >= Map.height) return false;
        // Conservative policy: avoid all map objects, walls and impassable effect tiles.
        if (Map.getTile(1, x, y) >= 0 || Map.getTile(2, x, y) === 1 ||
            Map.getTile(3, x, y) >= 0 || Map.getTile(5, x, y) >= 0) return false;
        for (var i = 0; i < npcs.length; i++) {
            if (npcs[i] === n) continue;
            var q = position(npcs[i]);
            if (q.x === x && q.y === y) return false;
        }
        for (var j = 0; j < App.players.length; j++) {
            if (App.players[j].tileX === x && App.players[j].tileY === y) return false;
        }
        return true;
    }
    function create(def, sprite) {
        if (!/^[a-z0-9_-]{1,64}$/.test(def.id)) throw new Error("Invalid NPC ID");
        if (npcs.some(function (n) { return n.id === def.id; })) throw new Error("Duplicate NPC ID");
        if ([def.x, def.y, def.minX, def.maxX, def.minY, def.maxY].some(function (v) {
            return typeof v !== "number" || !isFinite(v) || Math.floor(v) !== v;
        }) || def.minX < 0 || def.minY < 0 || def.maxX >= Map.width || def.maxY >= Map.height ||
            def.x < def.minX || def.x > def.maxX || def.y < def.minY || def.y > def.maxY) throw new Error("Invalid NPC patrol bounds");
        if (!canWalk(null, def.x, def.y)) throw new Error("NPC spawn blocked: " + def.id);
        var n = { id: def.id, key: "ai-npc:" + def.id, name: def.name };
        n.object = Map.putObjectWithKey(def.x, def.y, sprite, { key: n.key, type: 21,
            useDirAnim: true, impassable: false, movespeed: 58, activeDistance: NPC_CONFIG.stopRadius,
            triggerByTouch: false, npcProperty: { name: n.name } });
        var adapter = {
            position: function () { return position(n); },
            players: function () { return App.players.map(function (p) { return { id: p.id, x: p.tileX, y: p.tileY }; }); },
            canWalk: function (x, y) { return canWalk(n, x, y); },
            step: function (x, y, seconds) { Map.moveObjectWithKey(n.key, x, y, true, seconds); },
            stop: function () { var q = position(n); Map.moveObjectWithKey(n.key, q.x, q.y, false, 0.01); },
            openChat: function (p) { var actual = player(p.id); if (actual) open(n, actual); },
            closeChat: close
        };
        n.controller = new NpcController(adapter, { stopRadius: NPC_CONFIG.stopRadius,
            resumeRadius: NPC_CONFIG.resumeRadius, minX: def.minX, maxX: def.maxX, minY: def.minY, maxY: def.maxY });
        npcs.push(n);
    }
    function interact(p, key) {
        var best = null, d = Infinity;
        npcs.forEach(function (n) { var nd = distance(n, p); if ((!key || key === n.key) && nd < d) { best = n; d = nd; } });
        if (best && d <= NPC_CONFIG.stopRadius) best.controller.interact({ id: p.id, x: p.tileX, y: p.tileY });
    }
    App.onInit.Add(function () {
        var sprite = App.loadSpritesheet(NPC_CONFIG.sprite.file, NPC_CONFIG.sprite.frameWidth,
            NPC_CONFIG.sprite.frameHeight, NPC_CONFIG.sprite.animations, NPC_CONFIG.sprite.frameRate);
        NPC_CONFIG.characters.forEach(function (def) { create(def, sprite); });
        load();
    });
    App.onUpdate.Add(function (dt) {
        if (typeof dt !== "number" || !isFinite(dt) || dt < 0) return;
        clock += dt;
        npcs.forEach(function (n) { n.controller.tick(dt); });
        Object.keys(conversations).forEach(function (key) {
            if (clock - conversations[key].touched > 1800) delete conversations[key];
        });
    });
    // Direct F detection avoids relying on editor-only onTriggerObject behavior.
    App.addOnKeyDown(70, function (p) { interact(p); });
    App.onTriggerObject.Add(function (p, layer, x, y, key) { if (typeof key === "string") interact(p, key); });
    App.onAppObjectAttacked.Add(function (p, x, y, layer, key) { interact(p, key); });
    App.putMobilePunch(true); // On mobile, face the NPC and use the interaction/punch button.
    App.onLeavePlayer.Add(function (p) {
        var id = String(p.id); close(id);
        if (editors[id]) { editors[id].destroy(); delete editors[id]; }
        Object.keys(conversations).forEach(function (key) { if (key.indexOf(id + ":") === 0) delete conversations[key]; });
    });
    App.onSay.Add(function (p, text) {
        if (text === "!npc") { interact(p); return; }
        if (text === "!npc-admin") openEditor(p);
    });
}());
